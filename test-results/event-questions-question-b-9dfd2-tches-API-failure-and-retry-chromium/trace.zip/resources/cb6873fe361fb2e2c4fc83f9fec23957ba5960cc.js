(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_app_globals_162hn9o.css","static/chunks/node_modules_0xi-zrz._.js","static/chunks/src_04p4j3a._.js","static/chunks/src_app_error_tsx_0ts9uj7._.js","static/chunks/src_app_login_page_tsx_1cddrpa._.js"],
    source: "entry"
});
