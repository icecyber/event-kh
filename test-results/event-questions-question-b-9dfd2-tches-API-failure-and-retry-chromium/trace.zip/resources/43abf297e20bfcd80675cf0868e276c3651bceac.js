(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/AdminNotifications.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminNotifications
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AdminNotifications() {
    _s();
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Only show notifications for administrators / platform managers
    const isAdmin = session && (session.user.role === "ADMIN" || session.user.email === "admin@eventkh.com");
    const fetchNotifications = async ()=>{
        if (!isAdmin) return;
        try {
            const res = await fetch("/api/admin/notifications");
            if (res.ok) {
                const data = await res.json();
                setNotifications(data);
            }
        } catch (err) {
            console.error("Failed to load notifications:", err);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdminNotifications.useEffect": ()=>{
            fetchNotifications();
            // Poll every 15 seconds to fetch in real-time
            const interval = setInterval(fetchNotifications, 15000);
            return ({
                "AdminNotifications.useEffect": ()=>clearInterval(interval)
            })["AdminNotifications.useEffect"];
        }
    }["AdminNotifications.useEffect"], [
        session
    ]);
    // Close on click outside
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdminNotifications.useEffect": ()=>{
            const handler = {
                "AdminNotifications.useEffect.handler": (e)=>{
                    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                        setOpen(false);
                    }
                }
            }["AdminNotifications.useEffect.handler"];
            document.addEventListener("mousedown", handler);
            return ({
                "AdminNotifications.useEffect": ()=>document.removeEventListener("mousedown", handler)
            })["AdminNotifications.useEffect"];
        }
    }["AdminNotifications.useEffect"], []);
    if (!isAdmin) return null;
    const unreadCount = notifications.filter((n)=>!n.read).length;
    const handleMarkAsRead = async (id)=>{
        try {
            const res = await fetch(`/api/admin/notifications/${id}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    read: true
                })
            });
            if (res.ok) {
                setNotifications((prev)=>prev.map((n)=>n.id === id ? {
                            ...n,
                            read: true
                        } : n));
            }
        } catch (err) {
            console.error(err);
        }
    };
    const handleMarkAllRead = async ()=>{
        try {
            const res = await fetch("/api/admin/notifications", {
                method: "PUT"
            });
            if (res.ok) {
                setNotifications((prev)=>prev.map((n)=>({
                            ...n,
                            read: true
                        })));
            }
        } catch (err) {
            console.error(err);
        }
    };
    const fmtTime = (dateStr)=>{
        const date = new Date(dateStr);
        return date.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit"
        }) + " · " + date.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric"
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: dropdownRef,
        style: {
            position: "relative",
            display: "inline-block"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setOpen(!open),
                className: "btn btn-ghost",
                style: {
                    position: "relative",
                    padding: "0.5rem",
                    borderRadius: "50%",
                    width: "36px",
                    height: "36px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    background: open ? "var(--gray-100)" : "transparent"
                },
                "aria-label": "Platform administration notifications",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            fontSize: "1.2rem"
                        },
                        children: "🔔"
                    }, void 0, false, {
                        fileName: "[project]/src/components/AdminNotifications.tsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this),
                    unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            position: "absolute",
                            top: "2px",
                            right: "2px",
                            background: "#e11d48",
                            color: "#fff",
                            fontSize: "0.65rem",
                            fontWeight: 800,
                            minWidth: "16px",
                            height: "16px",
                            borderRadius: "50%",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            padding: "0 4px",
                            boxShadow: "0 0 0 2px #fff"
                        },
                        children: unreadCount
                    }, void 0, false, {
                        fileName: "[project]/src/components/AdminNotifications.tsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AdminNotifications.tsx",
                lineNumber: 102,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "absolute",
                    top: "calc(100% + 8px)",
                    right: 0,
                    width: "360px",
                    background: "#ffffff",
                    border: "1px solid var(--gray-200)",
                    borderRadius: "0.875rem",
                    boxShadow: "0 10px 30px rgba(0,0,0,0.12)",
                    zIndex: 1000,
                    overflow: "hidden",
                    animation: "fadeIn 0.15s ease"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: "1rem 1.25rem",
                            borderBottom: "1px solid var(--gray-100)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            background: "#fafafa"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontWeight: 800,
                                    fontSize: "0.95rem",
                                    color: "var(--gray-900)"
                                },
                                children: "Platform Alerts ⚡"
                            }, void 0, false, {
                                fileName: "[project]/src/components/AdminNotifications.tsx",
                                lineNumber: 172,
                                columnNumber: 13
                            }, this),
                            unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleMarkAllRead,
                                style: {
                                    background: "none",
                                    border: "none",
                                    color: "#e11d48",
                                    fontSize: "0.78rem",
                                    fontWeight: 700,
                                    cursor: "pointer",
                                    padding: 0
                                },
                                children: "Mark all read"
                            }, void 0, false, {
                                fileName: "[project]/src/components/AdminNotifications.tsx",
                                lineNumber: 176,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/AdminNotifications.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            maxHeight: "320px",
                            overflowY: "auto"
                        },
                        children: notifications.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                padding: "2.5rem 1.5rem",
                                textAlign: "center",
                                color: "var(--gray-400)"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        fontSize: "2rem",
                                        display: "block",
                                        marginBottom: "0.5rem"
                                    },
                                    children: "🎉"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AdminNotifications.tsx",
                                    lineNumber: 197,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        margin: 0,
                                        fontSize: "0.85rem",
                                        fontWeight: 500
                                    },
                                    children: "No notifications yet"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AdminNotifications.tsx",
                                    lineNumber: 198,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        margin: "0.2rem 0 0 0",
                                        fontSize: "0.75rem",
                                        color: "var(--gray-400)"
                                    },
                                    children: "match requests will appear here instantly."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/AdminNotifications.tsx",
                                    lineNumber: 199,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/AdminNotifications.tsx",
                            lineNumber: 196,
                            columnNumber: 15
                        }, this) : notifications.map((notif)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>!notif.read && handleMarkAsRead(notif.id),
                                style: {
                                    padding: "1rem 1.25rem",
                                    borderBottom: "1px solid var(--gray-50)",
                                    background: notif.read ? "transparent" : "rgba(225, 29, 72, 0.02)",
                                    cursor: notif.read ? "default" : "pointer",
                                    transition: "background 0.15s",
                                    display: "flex",
                                    gap: "0.75rem",
                                    alignItems: "flex-start"
                                },
                                onMouseEnter: (e)=>{
                                    if (!notif.read) e.currentTarget.style.background = "rgba(225, 29, 72, 0.05)";
                                },
                                onMouseLeave: (e)=>{
                                    if (!notif.read) e.currentTarget.style.background = "rgba(225, 29, 72, 0.02)";
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: "1.25rem",
                                            marginTop: "0.15rem",
                                            flexShrink: 0
                                        },
                                        children: "🤝"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/AdminNotifications.tsx",
                                        lineNumber: 225,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            flex: 1,
                                            minWidth: 0
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: "0.5rem",
                                                    justifyContent: "space-between"
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            fontWeight: 700,
                                                            fontSize: "0.85rem",
                                                            color: notif.read ? "var(--gray-700)" : "var(--gray-900)"
                                                        },
                                                        children: notif.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/AdminNotifications.tsx",
                                                        lineNumber: 228,
                                                        columnNumber: 23
                                                    }, this),
                                                    !notif.read && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            width: "6px",
                                                            height: "6px",
                                                            borderRadius: "50%",
                                                            background: "#e11d48",
                                                            flexShrink: 0
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/AdminNotifications.tsx",
                                                        lineNumber: 232,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/AdminNotifications.tsx",
                                                lineNumber: 227,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                style: {
                                                    margin: "0.25rem 0 0 0",
                                                    fontSize: "0.8rem",
                                                    color: "var(--gray-500)",
                                                    lineHeight: 1.45,
                                                    wordBreak: "break-word"
                                                },
                                                children: notif.message
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/AdminNotifications.tsx",
                                                lineNumber: 235,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    display: "block",
                                                    marginTop: "0.4rem",
                                                    fontSize: "0.72rem",
                                                    color: "var(--gray-400)"
                                                },
                                                children: fmtTime(notif.createdAt)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/AdminNotifications.tsx",
                                                lineNumber: 238,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/AdminNotifications.tsx",
                                        lineNumber: 226,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, notif.id, true, {
                                fileName: "[project]/src/components/AdminNotifications.tsx",
                                lineNumber: 205,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/AdminNotifications.tsx",
                        lineNumber: 194,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AdminNotifications.tsx",
                lineNumber: 146,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/AdminNotifications.tsx",
        lineNumber: 101,
        columnNumber: 5
    }, this);
}
_s(AdminNotifications, "t4/volCJdv4UO9O41i/PlvoSCDc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"]
    ];
});
_c = AdminNotifications;
var _c;
__turbopack_context__.k.register(_c, "AdminNotifications");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/LangProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LangProvider",
    ()=>LangProvider,
    "useLang",
    ()=>useLang
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/i18n.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const LangContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    locale: "en",
    setLocale: ()=>{},
    t: (key)=>key
});
const STORAGE_KEY = "eventkh-locale";
function LangProvider({ children }) {
    _s();
    const [locale, setLocaleState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("en");
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LangProvider.useEffect": ()=>{
            const stored = localStorage.getItem(STORAGE_KEY);
            if (stored && [
                "en",
                "km",
                "zh"
            ].includes(stored)) {
                setLocaleState(stored);
            }
            setMounted(true);
        }
    }["LangProvider.useEffect"], []);
    const setLocale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LangProvider.useCallback[setLocale]": (l)=>{
            setLocaleState(l);
            localStorage.setItem(STORAGE_KEY, l);
            document.documentElement.lang = l === "km" ? "km" : l === "zh" ? "zh" : "en";
        }
    }["LangProvider.useCallback[setLocale]"], []);
    const tFn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LangProvider.useCallback[tFn]": (key)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["t"])(key, locale)
    }["LangProvider.useCallback[tFn]"], [
        locale
    ]);
    // Avoid hydration mismatch — render children with "en" on server
    // then switch to stored locale on client mount
    if (!mounted) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LangContext.Provider, {
            value: {
                locale: "en",
                setLocale,
                t: (k)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["t"])(k, "en")
            },
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/LangProvider.tsx",
            lineNumber: 47,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LangContext.Provider, {
        value: {
            locale,
            setLocale,
            t: tFn
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/LangProvider.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(LangProvider, "vmwIBvBwa8tmr8F5Ysn+lGy4DMM=");
_c = LangProvider;
function useLang() {
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LangContext);
}
_s1(useLang, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "LangProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/LangSwitcher.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LangSwitcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LangProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/i18n.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function LangSwitcher() {
    _s();
    const { locale, setLocale } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLang"])();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const current = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOCALES"].find((l)=>l.code === locale) ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOCALES"][0];
    // Close on outside click
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LangSwitcher.useEffect": ()=>{
            const handler = {
                "LangSwitcher.useEffect.handler": (e)=>{
                    if (ref.current && !ref.current.contains(e.target)) setOpen(false);
                }
            }["LangSwitcher.useEffect.handler"];
            document.addEventListener("mousedown", handler);
            return ({
                "LangSwitcher.useEffect": ()=>document.removeEventListener("mousedown", handler)
            })["LangSwitcher.useEffect"];
        }
    }["LangSwitcher.useEffect"], []);
    const getFlagUrl = (flag)=>{
        if (flag === "🇬🇧") return "https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/1f1ec-1f1e7.png";
        if (flag === "🇰🇭") return "https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/1f1f0-1f1ed.png";
        if (flag === "🇨🇳") return "https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/1f1e8-1f1f3.png";
        return "";
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        style: {
            position: "relative",
            zIndex: 1000
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setOpen(!open),
                "aria-label": "Select language",
                style: {
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "0.35rem",
                    padding: "0.35rem 0.7rem",
                    borderRadius: "0.5rem",
                    cursor: "pointer",
                    background: "rgba(255,255,255,0.08)",
                    border: "1px solid var(--gray-200)",
                    color: "var(--gray-700)",
                    fontSize: "0.82rem",
                    fontWeight: 600,
                    transition: "all 0.15s"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: getFlagUrl(current.flag),
                        alt: current.label,
                        style: {
                            width: "1.1rem",
                            height: "1.1rem",
                            display: "inline-block",
                            verticalAlign: "middle",
                            objectFit: "contain"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/LangSwitcher.tsx",
                        lineNumber: 44,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: current.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/LangSwitcher.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            fontSize: "0.6rem",
                            opacity: 0.5,
                            marginLeft: "0.15rem"
                        },
                        children: "▼"
                    }, void 0, false, {
                        fileName: "[project]/src/components/LangSwitcher.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/LangSwitcher.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "absolute",
                    top: "calc(100% + 6px)",
                    right: 0,
                    minWidth: 150,
                    background: "#fff",
                    border: "1px solid var(--gray-200)",
                    borderRadius: "0.6rem",
                    boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
                    overflow: "hidden",
                    animation: "fadeIn 0.12s ease"
                },
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOCALES"].map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>{
                            setLocale(l.code);
                            setOpen(false);
                        },
                        style: {
                            display: "flex",
                            alignItems: "center",
                            gap: "0.5rem",
                            width: "100%",
                            padding: "0.65rem 1rem",
                            border: "none",
                            background: l.code === locale ? "var(--brand-50)" : "transparent",
                            color: l.code === locale ? "var(--brand-700)" : "var(--gray-700)",
                            fontWeight: l.code === locale ? 700 : 500,
                            fontSize: "0.875rem",
                            cursor: "pointer",
                            textAlign: "left",
                            transition: "background 0.1s"
                        },
                        onMouseEnter: (e)=>e.currentTarget.style.background = l.code === locale ? "var(--brand-50)" : "var(--gray-50)",
                        onMouseLeave: (e)=>e.currentTarget.style.background = l.code === locale ? "var(--brand-50)" : "transparent",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: getFlagUrl(l.flag),
                                alt: l.label,
                                style: {
                                    width: "1.2rem",
                                    height: "1.2rem",
                                    display: "inline-block",
                                    verticalAlign: "middle",
                                    objectFit: "contain"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/LangSwitcher.tsx",
                                lineNumber: 77,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: l.label
                            }, void 0, false, {
                                fileName: "[project]/src/components/LangSwitcher.tsx",
                                lineNumber: 82,
                                columnNumber: 15
                            }, this),
                            l.code === locale && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    marginLeft: "auto",
                                    fontSize: "0.8rem"
                                },
                                children: "✓"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LangSwitcher.tsx",
                                lineNumber: 83,
                                columnNumber: 37
                            }, this)
                        ]
                    }, l.code, true, {
                        fileName: "[project]/src/components/LangSwitcher.tsx",
                        lineNumber: 61,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/LangSwitcher.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/LangSwitcher.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(LangSwitcher, "yGbsgzYFWIA6CnagUXH5eOUkDAA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLang"]
    ];
});
_c = LangSwitcher;
var _c;
__turbopack_context__.k.register(_c, "LangSwitcher");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/NavBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NavBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LangProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LangSwitcher.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AdminNotifications$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AdminNotifications.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function NavBar() {
    _s();
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isOnDash = pathname?.startsWith("/dashboard");
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLang"])();
    const [menuOpen, setMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavBar.useEffect": ()=>{
            setMenuOpen(false);
        }
    }["NavBar.useEffect"], [
        pathname
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavBar.useEffect": ()=>{
            const handler = {
                "NavBar.useEffect.handler": (e)=>{
                    if (e.key === "Escape") setMenuOpen(false);
                }
            }["NavBar.useEffect.handler"];
            document.addEventListener("keydown", handler);
            return ({
                "NavBar.useEffect": ()=>document.removeEventListener("keydown", handler)
            })["NavBar.useEffect"];
        }
    }["NavBar.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "nav-bar",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/",
                className: "nav-logo",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "nav-logo-icon",
                        children: "⚡"
                    }, void 0, false, {
                        fileName: "[project]/src/components/NavBar.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    "EventKH"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/NavBar.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "nav-toggle",
                onClick: ()=>setMenuOpen(!menuOpen),
                "aria-label": "Toggle navigation",
                "aria-expanded": menuOpen,
                children: menuOpen ? "✕" : "☰"
            }, void 0, false, {
                fileName: "[project]/src/components/NavBar.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: `nav-links${menuOpen ? " open" : ""}`,
                children: [
                    !isOnDash && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/events",
                                className: "btn btn-ghost",
                                style: pathname === "/events" ? {
                                    background: "var(--blue-50)",
                                    color: "var(--blue-700)",
                                    fontWeight: 700
                                } : {},
                                children: [
                                    "📅 ",
                                    t("nav.browseEvents")
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/NavBar.tsx",
                                lineNumber: 46,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/matchmaking",
                                className: "btn btn-ghost",
                                style: pathname === "/matchmaking" ? {
                                    background: "var(--blue-50)",
                                    color: "var(--blue-700)",
                                    fontWeight: 700
                                } : {},
                                children: "🤝 Matchmaking"
                            }, void 0, false, {
                                fileName: "[project]/src/components/NavBar.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/NavBar.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this),
                    session ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/dashboard",
                                className: "btn btn-ghost",
                                style: isOnDash ? {
                                    background: "var(--blue-50)",
                                    color: "var(--blue-700)",
                                    fontWeight: 700
                                } : {},
                                children: [
                                    "📊 ",
                                    t("nav.dashboard")
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/NavBar.tsx",
                                lineNumber: 69,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])({
                                        callbackUrl: "/"
                                    }),
                                className: "btn btn-secondary btn-sm",
                                children: [
                                    "👋 ",
                                    t("nav.signOut")
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/NavBar.tsx",
                                lineNumber: 78,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/NavBar.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/login",
                                className: "btn btn-ghost",
                                style: pathname === "/login" ? {
                                    background: "var(--blue-50)",
                                    color: "var(--blue-700)",
                                    fontWeight: 700
                                } : {},
                                children: t("nav.logIn")
                            }, void 0, false, {
                                fileName: "[project]/src/components/NavBar.tsx",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/register",
                                className: "btn btn-primary btn-sm",
                                children: [
                                    "🚀 ",
                                    t("nav.signUp")
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/NavBar.tsx",
                                lineNumber: 96,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/NavBar.tsx",
                        lineNumber: 86,
                        columnNumber: 11
                    }, this),
                    session && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AdminNotifications$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/NavBar.tsx",
                        lineNumber: 102,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/NavBar.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/NavBar.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/NavBar.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_s(NavBar, "Cr3zCYFl7VE/c0z4uUooflG/xi8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LangProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLang"]
    ];
});
_c = NavBar;
var _c;
__turbopack_context__.k.register(_c, "NavBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Provider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
"use client";
;
;
const AuthProvider = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SessionProvider"], {
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/Provider.tsx",
        lineNumber: 6,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_c = AuthProvider;
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/i18n.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOCALES",
    ()=>LOCALES,
    "default",
    ()=>__TURBOPACK__default__export__,
    "t",
    ()=>t
]);
const LOCALES = [
    {
        code: "en",
        label: "English",
        flag: "🇬🇧"
    },
    {
        code: "km",
        label: "ខ្មែរ",
        flag: "🇰🇭"
    },
    {
        code: "zh",
        label: "中文",
        flag: "🇨🇳"
    }
];
// Flat key→translation dictionary per locale
const translations = {
    // ── NavBar ──────────────────────────────────────────────
    "nav.browseEvents": {
        en: "Browse Events",
        km: "រកមើលព្រឹត្តិការណ៍",
        zh: "浏览活动"
    },
    "nav.dashboard": {
        en: "Dashboard",
        km: "ផ្ទាំងគ្រប់គ្រង",
        zh: "控制台"
    },
    "nav.signOut": {
        en: "Sign out",
        km: "ចាកចេញ",
        zh: "退出登录"
    },
    "nav.logIn": {
        en: "Log in",
        km: "ចូល",
        zh: "登录"
    },
    "nav.signUp": {
        en: "Sign up",
        km: "ចុះឈ្មោះ",
        zh: "注册"
    },
    // ── Landing page ───────────────────────────────────────
    "home.badge": {
        en: "🎉 Free to use",
        km: "🎉 ប្រើប្រាស់ដោយឥតគិតថ្លៃ",
        zh: "🎉 免费使用"
    },
    "home.heroTitle1": {
        en: "The easiest way to manage ",
        km: "មធ្យោបាយងាយស្រួលបំផុតក្នុងការគ្រប់គ្រង ",
        zh: "管理柬埔寨活动"
    },
    "home.heroTitle2": {
        en: "events in Cambodia",
        km: "ព្រឹត្តិការណ៍នៅកម្ពុជា",
        zh: "最简单的方式"
    },
    "home.heroDesc": {
        en: "Create events, build custom registration forms, issue QR tickets, redeem check-ins, and export participant data — all in one place.",
        km: "បង្កើតព្រឹត្តិការណ៍ សង់ទម្រង់ចុះឈ្មោះផ្ទាល់ខ្លួន ចេញសំបុត្រ QR ស្កេនចូល និងនាំចេញទិន្នន័យអ្នកចូលរួម — ទាំងអស់នៅកន្លែងតែមួយ។",
        zh: "创建活动、构建自定义注册表单、发放二维码门票、扫码签到、导出参与者数据——一站式完成。"
    },
    "home.getStarted": {
        en: "Get Started Free →",
        km: "ចាប់ផ្តើមដោយឥតគិតថ្លៃ →",
        zh: "免费开始 →"
    },
    "home.browseEvents": {
        en: "Browse Events",
        km: "រកមើលព្រឹត្តិការណ៍",
        zh: "浏览活动"
    },
    "home.featuresTitle": {
        en: "Everything you need to run great events",
        km: "អ្វីគ្រប់យ៉ាងដែលអ្នកត្រូវការដើម្បីរៀបចំព្រឹត្តិការណ៍ល្អ",
        zh: "举办精彩活动所需的一切"
    },
    "home.featuresDesc": {
        en: "From registration to check-in, EventKH has you covered end-to-end.",
        km: "ពីការចុះឈ្មោះរហូតដល់ការស្កេនចូល EventKH គ្របដណ្តប់គ្រប់ជំហាន។",
        zh: "从注册到签到，EventKH 为您提供端到端服务。"
    },
    "home.ctaTitle": {
        en: "Ready to host your next event?",
        km: "ត្រៀមខ្លួនរៀបចំព្រឹត្តិការណ៍បន្ទាប់របស់អ្នកហើយ?",
        zh: "准备好举办您的下一个活动了吗？"
    },
    "home.ctaDesc": {
        en: "Sign up as an organizer and create your first event in minutes.",
        km: "ចុះឈ្មោះជាអ្នករៀបចំ ហើយបង្កើតព្រឹត្តិការណ៍ដំបូងរបស់អ្នកក្នុងរយៈពេលប៉ុន្មាននាទី។",
        zh: "注册成为组织者，几分钟内创建您的第一个活动。"
    },
    "home.createEvent": {
        en: "Create your event →",
        km: "បង្កើតព្រឹត្តិការណ៍ →",
        zh: "创建您的活动 →"
    },
    "home.footer": {
        en: "All rights reserved.",
        km: "រក្សាសិទ្ធិគ្រប់យ៉ាង។",
        zh: "版权所有。"
    },
    // ── Feature cards ──────────────────────────────────────
    "feat.createEvents": {
        en: "Create Events",
        km: "បង្កើតព្រឹត្តិការណ៍",
        zh: "创建活动"
    },
    "feat.createEventsDesc": {
        en: "Set up events with title, description, date, location, capacity, and banner image in minutes.",
        km: "រៀបចំព្រឹត្តិការណ៍ជាមួយចំណងជើង ការពិពណ៌នា កាលបរិច្ឆេទ ទីតាំង សមត្ថភាព និងរូបភាពបដា ក្នុងរយៈពេលប៉ុន្មាននាទី។",
        zh: "几分钟内设置活动的标题、描述、日期、地点、容量和横幅图片。"
    },
    "feat.customForms": {
        en: "Custom Forms",
        km: "ទម្រង់ផ្ទាល់ខ្លួន",
        zh: "自定义表单"
    },
    "feat.customFormsDesc": {
        en: "Build tailored registration forms with text, select, checkbox, and number fields.",
        km: "សង់ទម្រង់ចុះឈ្មោះផ្ទាល់ខ្លួនជាមួយវាលអត្ថបទ ជ្រើសរើស ប្រអប់ធីក និងលេខ។",
        zh: "使用文本、选择、复选框和数字字段构建定制注册表单。"
    },
    "feat.qrTickets": {
        en: "QR Code Tickets",
        km: "សំបុត្រ QR Code",
        zh: "二维码门票"
    },
    "feat.qrTicketsDesc": {
        en: "Every attendee gets a unique QR code for seamless check-in at the door.",
        km: "អ្នកចូលរួមគ្រប់រូបទទួលបាន QR code ពិសេសសម្រាប់ការស្កេនចូលដោយរលូន។",
        zh: "每位参与者获得唯一的二维码，实现无缝入场签到。"
    },
    "feat.pngBadges": {
        en: "PNG Badges",
        km: "ផ្លាកសញ្ញា PNG",
        zh: "PNG 徽章"
    },
    "feat.pngBadgesDesc": {
        en: "Issue beautiful branded badges with a custom background — ready to download instantly.",
        km: "ចេញផ្លាកសញ្ញាដ៏ស្រស់ស្អាតជាមួយផ្ទៃខាងក្រោយផ្ទាល់ខ្លួន — រួចរាល់សម្រាប់ទាញយកភ្លាមៗ។",
        zh: "发放带有自定义背景的精美品牌徽章——可立即下载。"
    },
    "feat.searchFilter": {
        en: "Search & Filter",
        km: "ស្វែងរក និងត្រង",
        zh: "搜索和筛选"
    },
    "feat.searchFilterDesc": {
        en: "Find any participant by name or email across all your events in real time.",
        km: "ស្វែងរកអ្នកចូលរួមតាមឈ្មោះ ឬអ៊ីមែលក្នុងព្រឹត្តិការណ៍ទាំងអស់របស់អ្នកក្នុងពេលវេលាជាក់ស្តែង។",
        zh: "实时通过姓名或电子邮件在所有活动中查找任何参与者。"
    },
    "feat.exportCsv": {
        en: "Export CSV",
        km: "នាំចេញ CSV",
        zh: "导出 CSV"
    },
    "feat.exportCsvDesc": {
        en: "Download all participant data including custom field answers to a spreadsheet.",
        km: "ទាញយកទិន្នន័យអ្នកចូលរួមទាំងអស់រួមទាំងចម្លើយវាលផ្ទាល់ខ្លួនទៅក្នុងសៀវភៅបញ្ជី។",
        zh: "下载所有参与者数据（包括自定义字段答案）到电子表格。"
    },
    // ── Auth pages ─────────────────────────────────────────
    "auth.signInTitle": {
        en: "Sign in to your account",
        km: "ចូលទៅគណនីរបស់អ្នក",
        zh: "登录您的账户"
    },
    "auth.orCreateAccount": {
        en: "Or",
        km: "ឬ",
        zh: "或者"
    },
    "auth.createNewAccount": {
        en: "create a new account",
        km: "បង្កើតគណនីថ្មី",
        zh: "创建新账户"
    },
    "auth.emailPlaceholder": {
        en: "Email address",
        km: "អាសយដ្ឋានអ៊ីមែល",
        zh: "电子邮箱"
    },
    "auth.passwordPlaceholder": {
        en: "Password",
        km: "ពាក្យសម្ងាត់",
        zh: "密码"
    },
    "auth.signInBtn": {
        en: "Sign in",
        km: "ចូល",
        zh: "登录"
    },
    "auth.signingIn": {
        en: "Signing in...",
        km: "កំពុងចូល...",
        zh: "正在登录..."
    },
    "auth.invalidCredentials": {
        en: "Invalid credentials. Please try again.",
        km: "ព័ត៌មានមិនត្រឹមត្រូវ។ សូមព្យាយាមម្តងទៀត។",
        zh: "凭据无效，请重试。"
    },
    "auth.createAccountTitle": {
        en: "Create a new account",
        km: "បង្កើតគណនីថ្មី",
        zh: "创建新账户"
    },
    "auth.alreadyHaveAccount": {
        en: "Already have an account?",
        km: "មានគណនីរួចហើយ?",
        zh: "已经有账户？"
    },
    "auth.signIn": {
        en: "Sign in",
        km: "ចូល",
        zh: "登录"
    },
    "auth.fullNamePlaceholder": {
        en: "Full Name",
        km: "ឈ្មោះពេញ",
        zh: "全名"
    },
    "auth.iAmA": {
        en: "I am a:",
        km: "ខ្ញុំជា:",
        zh: "我是："
    },
    "auth.attendee": {
        en: "Attendee",
        km: "អ្នកចូលរួម",
        zh: "参与者"
    },
    "auth.organizer": {
        en: "Event Organizer",
        km: "អ្នករៀបចំព្រឹត្តិការណ៍",
        zh: "活动组织者"
    },
    "auth.registerBtn": {
        en: "Register",
        km: "ចុះឈ្មោះ",
        zh: "注册"
    },
    "auth.registering": {
        en: "Registering...",
        km: "កំពុងចុះឈ្មោះ...",
        zh: "正在注册..."
    },
    // ── Browse Events ──────────────────────────────────────
    "events.title": {
        en: "Browse Events",
        km: "រកមើលព្រឹត្តិការណ៍",
        zh: "浏览活动"
    },
    "events.subtitle": {
        en: "Discover and register for upcoming events near you.",
        km: "ស្វែងរក និងចុះឈ្មោះសម្រាប់ព្រឹត្តិការណ៍នៅជិតអ្នក។",
        zh: "发现并注册您附近即将举行的活动。"
    },
    "events.noEvents": {
        en: "No events yet",
        km: "មិនទាន់មានព្រឹត្តិការណ៍",
        zh: "暂无活动"
    },
    "events.checkBackSoon": {
        en: "Check back soon — new events are being added all the time.",
        km: "សូមពិនិត្យមកម្តងទៀត — ព្រឹត្តិការណ៍ថ្មីកំពុងត្រូវបានបន្ថែម។",
        zh: "请稍后再来查看——新活动正在不断添加。"
    },
    "events.registered": {
        en: "registered",
        km: "បានចុះឈ្មោះ",
        zh: "已注册"
    },
    "events.capacity": {
        en: "capacity",
        km: "សមត្ថភាព",
        zh: "容量"
    },
    "events.by": {
        en: "By",
        km: "ដោយ",
        zh: "组织者"
    },
    "events.full": {
        en: "FULL",
        km: "ពេញ",
        zh: "已满"
    },
    "events.free": {
        en: "Free",
        km: "ឥតគិតថ្លៃ",
        zh: "免费"
    },
    // ── Event Detail ───────────────────────────────────────
    "event.about": {
        en: "About this event",
        km: "អំពីព្រឹត្តិការណ៍នេះ",
        zh: "关于此活动"
    },
    "event.registrationRequires": {
        en: "What you need to register",
        km: "អ្វីដែលអ្នកត្រូវការដើម្បីចុះឈ្មោះ",
        zh: "注册所需信息"
    },
    "event.organizedBy": {
        en: "Organized by",
        km: "រៀបចំដោយ",
        zh: "组织者"
    },
    "event.spotsLeft": {
        en: "spots left",
        km: "កន្លែងនៅសល់",
        zh: "剩余名额"
    },
    "event.tickets": {
        en: "Tickets",
        km: "សំបុត្រ",
        zh: "门票"
    },
    "event.alreadyRegistered": {
        en: "✅ You are already registered!",
        km: "✅ អ្នកបានចុះឈ្មោះរួចហើយ!",
        zh: "✅ 您已经注册了！"
    },
    "event.viewTicket": {
        en: "View My Ticket →",
        km: "មើលសំបុត្ររបស់ខ្ញុំ →",
        zh: "查看我的门票 →"
    },
    "event.eventFull": {
        en: "🚫 This event is full.",
        km: "🚫 ព្រឹត្តិការណ៍នេះពេញហើយ។",
        zh: "🚫 此活动已满。"
    },
    "event.registerNow": {
        en: "Register Now →",
        km: "ចុះឈ្មោះឥឡូវ →",
        zh: "立即注册 →"
    },
    "event.registerNoLogin": {
        en: "Register Now — No Login Required →",
        km: "ចុះឈ្មោះឥឡូវ — មិនចាំបាច់ចូលគណនី →",
        zh: "立即注册 — 无需登录 →"
    },
    "event.noAccountPhone": {
        en: "✨ No account needed — just your name & phone number",
        km: "✨ មិនចាំបាច់គណនី — គ្រាន់តែឈ្មោះ និងលេខទូរសព្ទ",
        zh: "✨ 无需账户——只需您的姓名和手机号"
    },
    "event.noAccountEmail": {
        en: "✨ No account needed — just your name & email address",
        km: "✨ មិនចាំបាច់គណនី — គ្រាន់តែឈ្មោះ និងអ៊ីមែល",
        zh: "✨ 无需账户——只需您的姓名和电子邮箱"
    },
    "event.exhibition": {
        en: "🎪 Exhibition",
        km: "🎪 ពិព័រណ៍",
        zh: "🎪 展览"
    },
    "event.standard": {
        en: "📅 Standard",
        km: "📅 ស្តង់ដារ",
        zh: "📅 标准"
    },
    "event.optional": {
        en: "(optional)",
        km: "(ជម្រើស)",
        zh: "(可选)"
    },
    // ── Registration form ──────────────────────────────────
    "reg.title": {
        en: "Registering for",
        km: "កំពុងចុះឈ្មោះសម្រាប់",
        zh: "注册参加"
    },
    "reg.guestAttendee": {
        en: "Guest Attendee",
        km: "អ្នកចូលរួមភ្ញៀវ",
        zh: "访客"
    },
    "reg.registeringAs": {
        en: "Registering as",
        km: "ចុះឈ្មោះក្នុងនាម",
        zh: "注册身份"
    },
    "reg.completeRegistration": {
        en: "Complete your registration",
        km: "បំពេញការចុះឈ្មោះរបស់អ្នក",
        zh: "完成您的注册"
    },
    "reg.yourDetails": {
        en: "Your Details",
        km: "ព័ត៌មានរបស់អ្នក",
        zh: "您的信息"
    },
    "reg.noAccountNeeded": {
        en: "No account needed! Just fill in your name and phone number.",
        km: "មិនចាំបាច់គណនី! គ្រាន់តែបំពេញឈ្មោះ និងលេខទូរសព្ទ។",
        zh: "无需账户！只需填写您的姓名和手机号。"
    },
    "reg.preFilled": {
        en: "We've pre-filled your info from your account. Feel free to update it.",
        km: "យើងបានបំពេញព័ត៌មានពីគណនីរបស់អ្នក។ អ្នកអាចកែប្រែវាបាន។",
        zh: "我们已从您的账户预填了信息，您可以随时修改。"
    },
    "reg.enterDetails": {
        en: "Please enter your contact details to register.",
        km: "សូមបំពេញព័ត៌មានទំនាក់ទំនងដើម្បីចុះឈ្មោះ។",
        zh: "请输入您的联系方式进行注册。"
    },
    "reg.fullName": {
        en: "Full Name",
        km: "ឈ្មោះពេញ",
        zh: "全名"
    },
    "reg.phoneNumber": {
        en: "Phone Number",
        km: "លេខទូរសព្ទ",
        zh: "手机号码"
    },
    "reg.emailAddress": {
        en: "Email Address",
        km: "អាសយដ្ឋានអ៊ីមែល",
        zh: "电子邮箱"
    },
    "reg.selectTicket": {
        en: "Select Ticket Type",
        km: "ជ្រើសរើសប្រភេទសំបុត្រ",
        zh: "选择门票类型"
    },
    "reg.completeBtn": {
        en: "Complete Registration →",
        km: "បញ្ចប់ការចុះឈ្មោះ →",
        zh: "完成注册 →"
    },
    "reg.registering": {
        en: "Registering…",
        km: "កំពុងចុះឈ្មោះ…",
        zh: "正在注册…"
    },
    // ── Common ─────────────────────────────────────────────
    "common.required": {
        en: "Required",
        km: "ចាំបាច់",
        zh: "必填"
    },
    "common.optional": {
        en: "Optional",
        km: "ជម្រើស",
        zh: "可选"
    }
};
function t(key, locale) {
    return translations[key]?.[locale] ?? translations[key]?.en ?? key;
}
const __TURBOPACK__default__export__ = translations;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_04p4j3a._.js.map